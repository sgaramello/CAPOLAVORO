using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OptionsButton : MonoBehaviour
{
    bool toggle;
    public GameObject finestra;
    void Start()
    {
        toggle = false;
    }

    public void opencloseOptions()
    {
        if (toggle)
        {
            finestra.SetActive(false);
            toggle = false;
        }
        else
        {
            finestra.SetActive(true);
            toggle = true;
        }
    }
}
