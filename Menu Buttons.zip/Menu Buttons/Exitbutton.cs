using UnityEngine;
using System.Collections;

// Quits the player when the user hits escape

public class Exitbutton : MonoBehaviour
{
    public void QuitCrab()
    {
        Debug.Log("ciao");
        Application.Quit();
        Debug.Log("ciao");

    } 
}