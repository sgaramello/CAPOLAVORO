using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class PickableItem : MonoBehaviour
{
    // Start is called before the first frame update

    private Rigidbody rb;
    public Rigidbody Rb => rb;
    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
    }
}
